# Interior Material Procurement & Usage Tracker

Complete 26-day internship project for Glory Simon Interiors

## 📋 Quick Start

### 1. Backend Setup
```bash
cd backend
npm install
npm start
```
Backend runs at: http://localhost:5000

### 2. Frontend Setup (Separate terminal)
```bash
cd frontend
npm install
npm run dev
```
Frontend runs at: http://localhost:5173

## 📁 Project Structure

```
material-tracker/
├── backend/              # Node.js + Express backend
│   ├── server.js        # Main server with all APIs
│   ├── package.json     # Dependencies
│   └── README.md        # Backend docs
├── frontend/            # React frontend
│   ├── src/
│   │   ├── App.jsx      # Main app component
│   │   ├── index.css    # Tailwind styles
│   │   └── main.jsx     # Entry point
│   └── package.json     # Dependencies
├── docs/                # Documentation files
├── tests/               # Test files
├── 26_DAYS_COMPLETE_GUIDE.md  # Full 26-day breakdown
└── README.md            # This file
```

## 🎯 Features Built

### Backend APIs
- ✅ Create material records
- ✅ List materials with filters
- ✅ Get material details
- ✅ Mark material received
- ✅ Record material usage
- ✅ Record wastage
- ✅ Calculate balance & costs
- ✅ Generate dashboard reports
- ✅ High wastage alerts

### Frontend Pages
- ✅ Material entry form
- ✅ Dashboard with all materials
- ✅ Detail page for each material
- ✅ Status tracking
- ✅ Real-time calculations
- ✅ Responsive design

## 📊 Key Calculations

- **Balance** = Received - Used - Wasted
- **Wastage %** = (Wasted / Received) × 100
- **Cost Per Unit** = Total Cost / Received
- **Cost of Used** = Used Qty × Cost Per Unit
- **Cost of Wasted** = Wasted Qty × Cost Per Unit

## 🧪 Testing

Use Postman to test APIs:
1. POST /api/materials (create)
2. GET /api/materials (list)
3. GET /api/materials/:id (detail)
4. POST /api/materials/:id/receive (receive)
5. POST /api/materials/:id/use (use)
6. POST /api/materials/:id/wastage (wastage)
7. POST /api/materials/:id/process (calculate)
8. GET /api/dashboard (dashboard)

## 🚀 Deployment

### Backend (Render.com or Railway.app)
1. Create account on Render.com
2. Deploy backend/folder
3. Get production URL

### Frontend (Vercel)
1. Connect GitHub
2. Deploy frontend folder
3. Update API URL in code

## 📅 Review Dates

- **Review 1** (06 June) - Planning & Design
- **Review 2** (19-20 June) - Development & Architecture
- **Review 3** (29-30 June) - Final Demo & Submission

## 📚 Documentation

See `26_DAYS_COMPLETE_GUIDE.md` for:
- Day-by-day breakdown
- Detailed task list
- Deliverables checklist
- Technology reference
- Tips for success

## ✅ Deliverables Checklist

- [ ] Backend APIs working
- [ ] Frontend connected
- [ ] Database schema setup
- [ ] All calculations working
- [ ] Dashboard functional
- [ ] Tests written
- [ ] Code pushed to GitHub
- [ ] Documentation complete
- [ ] Deployed and accessible
- [ ] Demo video recorded

## 🎓 What You'll Learn

- React fundamentals & hooks
- Node.js & Express.js
- REST API design
- Database design
- Testing & quality assurance
- Git & version control
- Deployment & DevOps
- Project management

## 📞 Support

For issues:
1. Check the 26_DAYS_COMPLETE_GUIDE.md
2. Review console logs
3. Test with Postman
4. Ask teammates
5. Contact instructor

---

**Status:** Ready to develop ✅  
**Team:** 3 Students (Frontend, Backend, Testing)  
**Duration:** 26 Working Days  
**Goal:** Working prototype + Full documentation

Good luck! 🚀
