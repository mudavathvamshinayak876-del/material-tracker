import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import { v4 as uuidv4 } from 'uuid';

dotenv.config();

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors());
app.use(express.json());

// In-memory database (for demo - replace with MongoDB later)
let materials = [];
let projects = [];
let users = [];

// ============================================
// MATERIALS ENDPOINTS
// ============================================

// POST /api/materials - Create new material record
app.post('/api/materials', (req, res) => {
  try {
    const { name, materialType, quantityOrdered, unit, supplier, projectId, date, estimatedCost } = req.body;
    
    // Validation
    if (!name || !quantityOrdered || !supplier) {
      return res.status(400).json({ error: 'Missing required fields' });
    }

    const material = {
      id: uuidv4(),
      name,
      materialType: materialType || 'General',
      quantityOrdered: parseFloat(quantityOrdered),
      quantityReceived: 0,
      quantityUsed: 0,
      quantityWasted: 0,
      unit: unit || 'Units',
      supplier,
      projectId: projectId || '',
      date: date || new Date().toISOString(),
      estimatedCost: parseFloat(estimatedCost) || 0,
      status: 'ordered',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      history: []
    };

    materials.push(material);
    
    console.log(`✅ Material created: ${material.name} (ID: ${material.id})`);
    res.status(201).json({ success: true, material });
  } catch (error) {
    console.error('Error creating material:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// GET /api/materials - List all materials with filters
app.get('/api/materials', (req, res) => {
  try {
    const { status, projectId, supplier } = req.query;
    
    let filtered = [...materials];
    
    if (status) filtered = filtered.filter(m => m.status === status);
    if (projectId) filtered = filtered.filter(m => m.projectId === projectId);
    if (supplier) filtered = filtered.filter(m => m.supplier === supplier);
    
    res.json({ success: true, count: filtered.length, materials: filtered });
  } catch (error) {
    console.error('Error fetching materials:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// GET /api/materials/:id - Get single material details
app.get('/api/materials/:id', (req, res) => {
  try {
    const { id } = req.params;
    const material = materials.find(m => m.id === id);
    
    if (!material) {
      return res.status(404).json({ error: 'Material not found' });
    }
    
    // Calculate derived fields
    const balance = material.quantityReceived - material.quantityUsed - material.quantityWasted;
    const wastagePercentage = material.quantityReceived > 0 
      ? ((material.quantityWasted / material.quantityReceived) * 100).toFixed(2)
      : 0;
    const costPerUnit = material.quantityReceived > 0
      ? (material.estimatedCost / material.quantityReceived).toFixed(2)
      : 0;
    
    const materialWithCalculations = {
      ...material,
      balance,
      wastagePercentage,
      costPerUnit
    };
    
    res.json({ success: true, material: materialWithCalculations });
  } catch (error) {
    console.error('Error fetching material:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// ============================================
// MATERIAL TRANSACTIONS - UPDATE STATUS
// ============================================

// POST /api/materials/:id/receive - Mark material as received
app.post('/api/materials/:id/receive', (req, res) => {
  try {
    const { id } = req.params;
    const { quantityReceived, date } = req.body;
    
    const material = materials.find(m => m.id === id);
    if (!material) {
      return res.status(404).json({ error: 'Material not found' });
    }
    
    material.quantityReceived = parseFloat(quantityReceived);
    material.status = 'received';
    material.updatedAt = new Date().toISOString();
    material.history.push({
      action: 'received',
      quantity: quantityReceived,
      date: date || new Date().toISOString(),
      timestamp: new Date().toISOString()
    });
    
    res.json({ success: true, material });
  } catch (error) {
    console.error('Error updating material:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// POST /api/materials/:id/use - Mark material as used
app.post('/api/materials/:id/use', (req, res) => {
  try {
    const { id } = req.params;
    const { quantityUsed, date } = req.body;
    
    const material = materials.find(m => m.id === id);
    if (!material) {
      return res.status(404).json({ error: 'Material not found' });
    }
    
    material.quantityUsed = parseFloat(quantityUsed);
    material.status = 'in-use';
    material.updatedAt = new Date().toISOString();
    material.history.push({
      action: 'used',
      quantity: quantityUsed,
      date: date || new Date().toISOString(),
      timestamp: new Date().toISOString()
    });
    
    res.json({ success: true, material });
  } catch (error) {
    console.error('Error updating material:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// POST /api/materials/:id/wastage - Record wastage
app.post('/api/materials/:id/wastage', (req, res) => {
  try {
    const { id } = req.params;
    const { quantityWasted, reason, date } = req.body;
    
    const material = materials.find(m => m.id === id);
    if (!material) {
      return res.status(404).json({ error: 'Material not found' });
    }
    
    material.quantityWasted = parseFloat(quantityWasted);
    material.updatedAt = new Date().toISOString();
    material.history.push({
      action: 'wastage',
      quantity: quantityWasted,
      reason: reason || 'Not specified',
      date: date || new Date().toISOString(),
      timestamp: new Date().toISOString()
    });
    
    res.json({ success: true, material });
  } catch (error) {
    console.error('Error updating material:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// ============================================
// CALCULATION & REPORTING ENDPOINTS
// ============================================

// POST /api/materials/:id/process - Calculate balance and generate report
app.post('/api/materials/:id/process', (req, res) => {
  try {
    const { id } = req.params;
    const material = materials.find(m => m.id === id);
    
    if (!material) {
      return res.status(404).json({ error: 'Material not found' });
    }
    
    // Calculations
    const balance = material.quantityReceived - material.quantityUsed - material.quantityWasted;
    const wastagePercentage = material.quantityReceived > 0 
      ? ((material.quantityWasted / material.quantityReceived) * 100).toFixed(2)
      : 0;
    const costPerUnit = material.quantityReceived > 0
      ? (material.estimatedCost / material.quantityReceived).toFixed(2)
      : 0;
    const totalCost = material.estimatedCost;
    const costOfUsed = (material.quantityUsed * costPerUnit).toFixed(2);
    const costOfWasted = (material.quantityWasted * costPerUnit).toFixed(2);
    const costOfBalance = (balance * costPerUnit).toFixed(2);
    
    // Determine alerts
    const alerts = [];
    if (wastagePercentage > 20) {
      alerts.push(`⚠️ High wastage: ${wastagePercentage}%`);
    }
    if (balance === 0) {
      alerts.push('⏱️ Material fully used');
    }
    if (balance < 0) {
      alerts.push('❌ Over-usage detected!');
    }
    
    // Update status
    if (balance === 0) {
      material.status = 'completed';
    } else if (material.quantityUsed > 0) {
      material.status = 'in-progress';
    }
    
    material.updatedAt = new Date().toISOString();
    
    const report = {
      materialId: id,
      materialName: material.name,
      ordered: material.quantityOrdered,
      received: material.quantityReceived,
      used: material.quantityUsed,
      wasted: material.quantityWasted,
      balance,
      costPerUnit: parseFloat(costPerUnit),
      totalCost,
      costOfUsed: parseFloat(costOfUsed),
      costOfWasted: parseFloat(costOfWasted),
      costOfBalance: parseFloat(costOfBalance),
      wastagePercentage: parseFloat(wastagePercentage),
      efficiency: (100 - parseFloat(wastagePercentage)).toFixed(2),
      status: material.status,
      alerts,
      generatedAt: new Date().toISOString()
    };
    
    console.log(`📊 Report generated for: ${material.name}`);
    res.json({ success: true, report, material });
  } catch (error) {
    console.error('Error processing material:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// GET /api/dashboard - Dashboard with summary statistics
app.get('/api/dashboard', (req, res) => {
  try {
    const totalMaterials = materials.length;
    const totalOrdered = materials.reduce((sum, m) => sum + m.quantityOrdered, 0);
    const totalReceived = materials.reduce((sum, m) => sum + m.quantityReceived, 0);
    const totalUsed = materials.reduce((sum, m) => sum + m.quantityUsed, 0);
    const totalWasted = materials.reduce((sum, m) => sum + m.quantityWasted, 0);
    const totalCost = materials.reduce((sum, m) => sum + m.estimatedCost, 0);
    
    const statusCounts = {
      ordered: materials.filter(m => m.status === 'ordered').length,
      received: materials.filter(m => m.status === 'received').length,
      'in-use': materials.filter(m => m.status === 'in-use').length,
      'in-progress': materials.filter(m => m.status === 'in-progress').length,
      completed: materials.filter(m => m.status === 'completed').length
    };
    
    const avgWastage = totalReceived > 0 
      ? ((totalWasted / totalReceived) * 100).toFixed(2)
      : 0;
    
    const dashboard = {
      summary: {
        totalMaterials,
        totalOrdered,
        totalReceived,
        totalUsed,
        totalWasted,
        totalCost: parseFloat(totalCost.toFixed(2)),
        averageWastagePercentage: parseFloat(avgWastage)
      },
      statusCounts,
      recentMaterials: materials.slice(-5).reverse(),
      highWastageMaterials: materials
        .filter(m => m.quantityReceived > 0 && (m.quantityWasted / m.quantityReceived) * 100 > 20)
        .map(m => ({
          id: m.id,
          name: m.name,
          wastagePercentage: ((m.quantityWasted / m.quantityReceived) * 100).toFixed(2)
        }))
    };
    
    res.json({ success: true, dashboard });
  } catch (error) {
    console.error('Error fetching dashboard:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// DELETE /api/materials/:id - Delete material record
app.delete('/api/materials/:id', (req, res) => {
  try {
    const { id } = req.params;
    const index = materials.findIndex(m => m.id === id);
    
    if (index === -1) {
      return res.status(404).json({ error: 'Material not found' });
    }
    
    const deleted = materials.splice(index, 1);
    res.json({ success: true, message: 'Material deleted', material: deleted[0] });
  } catch (error) {
    console.error('Error deleting material:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// ============================================
// HEALTH CHECK
// ============================================

app.get('/api/health', (req, res) => {
  res.json({ 
    status: 'ok',
    message: 'Interior Material Procurement Tracker API is running',
    timestamp: new Date().toISOString()
  });
});

// Root endpoint
app.get('/', (req, res) => {
  res.json({
    name: 'Interior Material Procurement & Usage Tracker',
    version: '1.0.0',
    endpoints: {
      'POST /api/materials': 'Create new material',
      'GET /api/materials': 'List all materials',
      'GET /api/materials/:id': 'Get material details',
      'POST /api/materials/:id/receive': 'Mark material received',
      'POST /api/materials/:id/use': 'Mark material used',
      'POST /api/materials/:id/wastage': 'Record wastage',
      'POST /api/materials/:id/process': 'Calculate and generate report',
      'GET /api/dashboard': 'Get dashboard summary',
      'DELETE /api/materials/:id': 'Delete material'
    }
  });
});

// Error handling middleware
app.use((err, req, res, next) => {
  console.error('Error:', err);
  res.status(500).json({ error: 'Internal server error' });
});

// Start server
app.listen(PORT, () => {
  console.log(`
╔════════════════════════════════════════════════════╗
║   Interior Material Procurement Tracker Backend    ║
║   Running on http://localhost:${PORT}                ║
║   Environment: ${process.env.NODE_ENV || 'development'}               ║
╚════════════════════════════════════════════════════╝
  `);
});

export default app;
