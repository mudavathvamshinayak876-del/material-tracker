import { useState, useEffect } from 'react';
import axios from 'axios';
import './App.css';

const API_URL = 'http://localhost:5000/api';

function App() {
  const [materials, setMaterials] = useState([]);
  const [formData, setFormData] = useState({
    name: '',
    materialType: '',
    quantityOrdered: '',
    unit: 'Units',
    supplier: '',
    projectId: '',
    estimatedCost: ''
  });
  const [selectedMaterial, setSelectedMaterial] = useState(null);
  const [loading, setLoading] = useState(false);
  const [currentPage, setCurrentPage] = useState('dashboard');
  const [transactionData, setTransactionData] = useState({
    quantityReceived: '',
    quantityUsed: '',
    quantityWasted: '',
    reason: ''
  });

  // Fetch materials on component mount
  useEffect(() => {
    fetchMaterials();
  }, []);

  const fetchMaterials = async () => {
    try {
      setLoading(true);
      const response = await axios.get(`${API_URL}/materials`);
      setMaterials(response.data.materials);
    } catch (error) {
      console.error('Error fetching materials:', error);
      alert('Error fetching materials');
    } finally {
      setLoading(false);
    }
  };

  const handleFormChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleTransactionChange = (e) => {
    const { name, value } = e.target;
    setTransactionData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleAddMaterial = async (e) => {
    e.preventDefault();
    if (!formData.name || !formData.quantityOrdered || !formData.supplier) {
      alert('Please fill required fields');
      return;
    }

    try {
      const response = await axios.post(`${API_URL}/materials`, formData);
      setMaterials([...materials, response.data.material]);
      setFormData({
        name: '',
        materialType: '',
        quantityOrdered: '',
        unit: 'Units',
        supplier: '',
        projectId: '',
        estimatedCost: ''
      });
      alert('✅ Material added successfully!');
    } catch (error) {
      console.error('Error adding material:', error);
      alert('Error adding material');
    }
  };

  const handleViewDetails = async (materialId) => {
    try {
      const response = await axios.get(`${API_URL}/materials/${materialId}`);
      setSelectedMaterial(response.data.material);
      setCurrentPage('detail');
    } catch (error) {
      console.error('Error fetching material details:', error);
      alert('Error fetching material details');
    }
  };

  const handleReceiveMaterial = async (materialId) => {
    const qty = prompt('Enter received quantity:');
    if (!qty) return;

    try {
      const response = await axios.post(`${API_URL}/materials/${materialId}/receive`, {
        quantityReceived: qty,
        date: new Date().toISOString()
      });
      fetchMaterials();
      if (selectedMaterial?.id === materialId) {
        setSelectedMaterial(response.data.material);
      }
      alert('✅ Material marked as received!');
    } catch (error) {
      console.error('Error:', error);
      alert('Error updating material');
    }
  };

  const handleUseMaterial = async (materialId) => {
    const qty = prompt('Enter quantity used:');
    if (!qty) return;

    try {
      const response = await axios.post(`${API_URL}/materials/${materialId}/use`, {
        quantityUsed: qty,
        date: new Date().toISOString()
      });
      fetchMaterials();
      if (selectedMaterial?.id === materialId) {
        setSelectedMaterial(response.data.material);
      }
      alert('✅ Usage recorded!');
    } catch (error) {
      console.error('Error:', error);
      alert('Error updating material');
    }
  };

  const handleWastage = async (materialId) => {
    const qty = prompt('Enter wastage quantity:');
    if (!qty) return;

    try {
      const response = await axios.post(`${API_URL}/materials/${materialId}/wastage`, {
        quantityWasted: qty,
        reason: 'Damage or loss',
        date: new Date().toISOString()
      });
      fetchMaterials();
      if (selectedMaterial?.id === materialId) {
        setSelectedMaterial(response.data.material);
      }
      alert('✅ Wastage recorded!');
    } catch (error) {
      console.error('Error:', error);
      alert('Error recording wastage');
    }
  };

  const handleGenerateReport = async (materialId) => {
    try {
      const response = await axios.post(`${API_URL}/materials/${materialId}/process`);
      alert('📊 Report:\n\n' + JSON.stringify(response.data.report, null, 2));
    } catch (error) {
      console.error('Error:', error);
      alert('Error generating report');
    }
  };

  const handleDeleteMaterial = async (materialId) => {
    if (!confirm('Are you sure you want to delete this material?')) return;

    try {
      await axios.delete(`${API_URL}/materials/${materialId}`);
      fetchMaterials();
      alert('✅ Material deleted!');
    } catch (error) {
      console.error('Error:', error);
      alert('Error deleting material');
    }
  };

  // Dashboard Page
  const renderDashboard = () => (
    <div className="page">
      <h1>📊 Material Procurement Dashboard</h1>
      
      {loading ? (
        <p>Loading...</p>
      ) : (
        <div className="dashboard">
          <div className="summary">
            <div className="stat">
              <h3>Total Materials</h3>
              <p className="number">{materials.length}</p>
            </div>
            <div className="stat">
              <h3>Total Ordered</h3>
              <p className="number">{materials.reduce((sum, m) => sum + (m.quantityOrdered || 0), 0)}</p>
            </div>
            <div className="stat">
              <h3>Total Received</h3>
              <p className="number">{materials.reduce((sum, m) => sum + (m.quantityReceived || 0), 0)}</p>
            </div>
            <div className="stat">
              <h3>Total Used</h3>
              <p className="number">{materials.reduce((sum, m) => sum + (m.quantityUsed || 0), 0)}</p>
            </div>
          </div>

          <div className="materials-list">
            <h2>All Materials</h2>
            {materials.length === 0 ? (
              <p>No materials added yet</p>
            ) : (
              <table>
                <thead>
                  <tr>
                    <th>Name</th>
                    <th>Type</th>
                    <th>Supplier</th>
                    <th>Ordered</th>
                    <th>Received</th>
                    <th>Used</th>
                    <th>Wasted</th>
                    <th>Status</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {materials.map(material => (
                    <tr key={material.id}>
                      <td>{material.name}</td>
                      <td>{material.materialType}</td>
                      <td>{material.supplier}</td>
                      <td>{material.quantityOrdered}</td>
                      <td>{material.quantityReceived}</td>
                      <td>{material.quantityUsed}</td>
                      <td>{material.quantityWasted}</td>
                      <td><span className={`status ${material.status}`}>{material.status}</span></td>
                      <td>
                        <button onClick={() => handleViewDetails(material.id)}>View</button>
                        <button onClick={() => handleReceiveMaterial(material.id)}>Receive</button>
                        <button onClick={() => handleUseMaterial(material.id)}>Use</button>
                        <button onClick={() => handleWastage(material.id)}>Wastage</button>
                        <button onClick={() => handleGenerateReport(material.id)}>Report</button>
                        <button onClick={() => handleDeleteMaterial(material.id)} className="delete">Delete</button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
        </div>
      )}
    </div>
  );

  // Form Page
  const renderForm = () => (
    <div className="page">
      <h1>➕ Add New Material</h1>
      <form onSubmit={handleAddMaterial} className="form">
        <div className="form-group">
          <label>Material Name *</label>
          <input
            type="text"
            name="name"
            value={formData.name}
            onChange={handleFormChange}
            placeholder="e.g., Plywood 4x8"
            required
          />
        </div>

        <div className="form-group">
          <label>Material Type</label>
          <select name="materialType" value={formData.materialType} onChange={handleFormChange}>
            <option value="">Select Type</option>
            <option value="Wood">Wood</option>
            <option value="Paint">Paint</option>
            <option value="Flooring">Flooring</option>
            <option value="Hardware">Hardware</option>
            <option value="Other">Other</option>
          </select>
        </div>

        <div className="form-group">
          <label>Quantity Ordered *</label>
          <input
            type="number"
            name="quantityOrdered"
            value={formData.quantityOrdered}
            onChange={handleFormChange}
            placeholder="Enter quantity"
            required
          />
        </div>

        <div className="form-group">
          <label>Unit</label>
          <select name="unit" value={formData.unit} onChange={handleFormChange}>
            <option value="Units">Units</option>
            <option value="Sheets">Sheets</option>
            <option value="Kg">Kg</option>
            <option value="Liters">Liters</option>
            <option value="Meters">Meters</option>
          </select>
        </div>

        <div className="form-group">
          <label>Supplier *</label>
          <input
            type="text"
            name="supplier"
            value={formData.supplier}
            onChange={handleFormChange}
            placeholder="Supplier name"
            required
          />
        </div>

        <div className="form-group">
          <label>Project ID</label>
          <input
            type="text"
            name="projectId"
            value={formData.projectId}
            onChange={handleFormChange}
            placeholder="Project ID"
          />
        </div>

        <div className="form-group">
          <label>Estimated Cost</label>
          <input
            type="number"
            name="estimatedCost"
            value={formData.estimatedCost}
            onChange={handleFormChange}
            placeholder="Enter cost"
          />
        </div>

        <button type="submit">Add Material</button>
      </form>
    </div>
  );

  // Detail Page
  const renderDetail = () => {
    if (!selectedMaterial) return <p>Loading...</p>;

    const balance = selectedMaterial.quantityReceived - selectedMaterial.quantityUsed - selectedMaterial.quantityWasted;
    const wastagePercent = selectedMaterial.quantityReceived > 0 
      ? ((selectedMaterial.quantityWasted / selectedMaterial.quantityReceived) * 100).toFixed(2)
      : 0;
    const costPerUnit = selectedMaterial.quantityReceived > 0
      ? (selectedMaterial.estimatedCost / selectedMaterial.quantityReceived).toFixed(2)
      : 0;

    return (
      <div className="page">
        <button onClick={() => setCurrentPage('dashboard')} className="back-btn">← Back</button>
        
        <h1>{selectedMaterial.name}</h1>
        
        <div className="detail-grid">
          <div className="detail-card">
            <h3>Quantities</h3>
            <p><strong>Ordered:</strong> {selectedMaterial.quantityOrdered} {selectedMaterial.unit}</p>
            <p><strong>Received:</strong> {selectedMaterial.quantityReceived} {selectedMaterial.unit}</p>
            <p><strong>Used:</strong> {selectedMaterial.quantityUsed} {selectedMaterial.unit}</p>
            <p><strong>Wasted:</strong> {selectedMaterial.quantityWasted} {selectedMaterial.unit}</p>
            <p><strong>Balance:</strong> {balance} {selectedMaterial.unit}</p>
          </div>

          <div className="detail-card">
            <h3>Costs</h3>
            <p><strong>Total Cost:</strong> ₹{selectedMaterial.estimatedCost.toFixed(2)}</p>
            <p><strong>Cost Per Unit:</strong> ₹{costPerUnit}</p>
            <p><strong>Cost of Used:</strong> ₹{(selectedMaterial.quantityUsed * costPerUnit).toFixed(2)}</p>
            <p><strong>Cost of Wasted:</strong> ₹{(selectedMaterial.quantityWasted * costPerUnit).toFixed(2)}</p>
            <p><strong>Cost of Balance:</strong> ₹{(balance * costPerUnit).toFixed(2)}</p>
          </div>

          <div className="detail-card">
            <h3>Efficiency</h3>
            <p><strong>Wastage:</strong> {wastagePercent}%</p>
            <p><strong>Efficiency:</strong> {(100 - wastagePercent).toFixed(2)}%</p>
            <p><strong>Status:</strong> <span className={`status ${selectedMaterial.status}`}>{selectedMaterial.status}</span></p>
            <p><strong>Supplier:</strong> {selectedMaterial.supplier}</p>
          </div>

          <div className="detail-card">
            <h3>History</h3>
            {selectedMaterial.history && selectedMaterial.history.length > 0 ? (
              <ul>
                {selectedMaterial.history.map((h, idx) => (
                  <li key={idx}>{h.action}: {h.quantity} ({new Date(h.timestamp).toLocaleDateString()})</li>
                ))}
              </ul>
            ) : (
              <p>No history yet</p>
            )}
          </div>
        </div>

        <div className="action-buttons">
          <button onClick={() => handleReceiveMaterial(selectedMaterial.id)}>📥 Receive</button>
          <button onClick={() => handleUseMaterial(selectedMaterial.id)}>📦 Use</button>
          <button onClick={() => handleWastage(selectedMaterial.id)}>⚠️ Wastage</button>
          <button onClick={() => handleGenerateReport(selectedMaterial.id)}>📊 Report</button>
        </div>
      </div>
    );
  };

  return (
    <div className="App">
      <header>
        <h1>🏠 Interior Material Procurement Tracker</h1>
        <div className="nav">
          <button 
            className={currentPage === 'dashboard' ? 'active' : ''} 
            onClick={() => setCurrentPage('dashboard')}
          >
            📊 Dashboard
          </button>
          <button 
            className={currentPage === 'form' ? 'active' : ''} 
            onClick={() => setCurrentPage('form')}
          >
            ➕ Add Material
          </button>
        </div>
      </header>

      <main>
        {currentPage === 'dashboard' && renderDashboard()}
        {currentPage === 'form' && renderForm()}
        {currentPage === 'detail' && renderDetail()}
      </main>

      <footer>
        <p>Glory Simon Interiors | Material Procurement System v1.0 | © 2026</p>
      </footer>
    </div>
  );
}

export default App;
