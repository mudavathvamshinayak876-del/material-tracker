# INTERIOR MATERIAL PROCUREMENT & USAGE TRACKER
## 26-Day Internship Project - Complete Guide & Checklist

---

## PROJECT OVERVIEW

**Company:** Glory Simon Interiors  
**Project:** Interior Material Procurement & Usage Tracker  
**Duration:** 26 Working Days (01 June - 30 June 2026)  
**Team Size:** 3 Students  
**Roles:** Frontend | Backend | Testing & Deployment

---

## WHAT WE'RE BUILDING

A complete system that tracks material procurement for interior projects:
- Material orders (plywood, paint, etc.) → received → used → wastage → balance
- Links materials to supplier invoices and project sites
- Calculates true material cost per project
- Prevents over-purchasing
- Shows procurement dashboard with alerts

---

## TECHNOLOGY STACK

```
Frontend:    React 18 + Tailwind CSS
Backend:     Node.js + Express.js
Database:    MongoDB / Firebase
Testing:     Jest + Postman
Deployment:  Vercel (Frontend) + Render/Railway (Backend)
```

---

## TEAM ROLES & RESPONSIBILITIES

### Student 1: Frontend Developer
**Deliverables:**
- Material purchase entry form
- Project material ledger / Dashboard
- Supplier bill upload UI
- Usage variance view
- Detail page for each material
- Responsive UI with React

**Key Skills Needed:**
- React hooks, components
- Form handling & validation
- Fetching data from APIs
- Tailwind CSS styling

### Student 2: Backend Developer
**Deliverables:**
- Procurement APIs (create, read, update, list)
- Database schema & setup
- Material usage calculation logic
- Wastage calculation
- Stock ledger generation
- Cost variance reports

**Key Skills Needed:**
- Node.js + Express
- REST API design
- Database (MongoDB/Firebase)
- Business logic implementation

### Student 3: Testing & Deployment
**Deliverables:**
- Test cases for all features
- API testing with Postman
- End-to-end testing
- Deployment setup
- GitHub repository management
- Documentation & guides

**Key Skills Needed:**
- Testing methodology
- Postman API testing
- Git/GitHub
- Deployment (Vercel, Render)
- Documentation writing

---

## DETAILED 26-DAY BREAKDOWN

### WEEK 1: PLANNING & DOCUMENTATION

#### **Day 1 - 01 June (Monday) - Introduction Session**

**ALL STUDENTS:**
- Watch introduction video
- Read entire project document
- Understand company background
- Understand problem statement

**STUDENT 1 (Frontend):**
- [ ] Sketch 3 screens on paper: input form, dashboard, detail page
- [ ] Understand frontend modules
- [ ] Start logbook Day 1

**STUDENT 2 (Backend):**
- [ ] Write down 5 backend API questions
- [ ] List database tables needed
- [ ] Start logbook Day 1

**STUDENT 3 (Testing):**
- [ ] Research what software testing means
- [ ] Research Git/GitHub basics
- [ ] Create GitHub account (if needed)
- [ ] Start logbook Day 1

**Deliverable:** Groups formed, logbooks started, project understood

---

#### **Day 2 - 02 June (Tuesday) - Problem Statement & Abstract**

**STUDENT 1 (Frontend):**
- [ ] Write problem statement (4-5 sentences from UI perspective)
- [ ] List all screens needed
- [ ] Write project abstract
- [ ] Update logbook

**STUDENT 2 (Backend):**
- [ ] Write problem statement (from technical perspective)
- [ ] List all backend operations needed
- [ ] Write abstract explaining system architecture
- [ ] Update logbook

**STUDENT 3 (Testing):**
- [ ] Create GitHub repository
- [ ] Set up folders: /frontend, /backend, /docs, /tests
- [ ] Push README.md with project title, team names, tech stack
- [ ] Update logbook

**Deliverable:** Problem Statement draft, Abstract draft, GitHub repo created

---

#### **Day 3 - 03 June (Wednesday) - Project Objectives & Tech Setup**

**STUDENT 1 (Frontend):**
- [ ] Write 5 frontend objectives
- [ ] Install VS Code
- [ ] Install Node.js (v16+)
- [ ] Create /frontend folder
- [ ] Create first React component
- [ ] Update logbook

**STUDENT 2 (Backend):**
- [ ] Write 5 backend objectives
- [ ] Install Node.js
- [ ] Initialize Express project: `npm init -y && npm install express`
- [ ] Create server.js with Hello route
- [ ] Test: `node server.js` → http://localhost:5000
- [ ] Update logbook

**STUDENT 3 (Testing):**
- [ ] Write 5 testing/QA objectives
- [ ] Install Postman
- [ ] Test backend Hello route in Postman
- [ ] Document test result in test log
- [ ] Update logbook

**Deliverable:** Objectives written, tools installed, first working code

---

#### **Day 4 - 04 June (Thursday) - Wireframes & API Design**

**STUDENT 1 (Frontend):**
- [ ] Draw wireframes for 4 screens:
  - Input form (material entry)
  - Dashboard (all materials list)
  - Detail page (single material)
  - Workflow/status page
- [ ] Use paper or Figma free
- [ ] Upload images to GitHub /docs
- [ ] Update logbook

**STUDENT 2 (Backend):**
- [ ] Draw API endpoint list
- [ ] Define each endpoint with request/response structure
- [ ] APIs needed:
  - POST /api/materials (create)
  - GET /api/materials (list)
  - GET /api/materials/:id (detail)
  - PUT /api/materials/:id (update)
  - POST /api/materials/:id/process (calculate)
- [ ] Update logbook

**STUDENT 3 (Testing):**
- [ ] Review wireframes for completeness
- [ ] Write initial test cases (5+ test cases)
- [ ] Push test case document to GitHub
- [ ] Update logbook

**Deliverable:** Wireframes, API endpoint list, test cases document

---

#### **Day 5 - 05 June (Friday) - Review 1 Preparation**

**ALL STUDENTS:**
- [ ] Prepare Review 1 PowerPoint slides
- [ ] Do mock presentation (practice)
- [ ] Verify all documents pushed to GitHub

**STUDENT 1 (Frontend):**
- [ ] Add slides: Wireframes, UI design, screen list
- [ ] Present frontend sections in mock

**STUDENT 2 (Backend):**
- [ ] Add slides: Problem, proposed system, tech stack, API design
- [ ] Present backend sections in mock

**STUDENT 3 (Testing):**
- [ ] Add slides: Objectives, test plan, GitHub setup
- [ ] Verify repo is clean and visible
- [ ] Present testing sections in mock

**Deliverable:** Review 1 PPT complete, all docs on GitHub, mock done

---

#### **Day 6 - 06 June (Saturday) - REVIEW 1 PRESENTATION**

**ALL STUDENTS - PRESENT TO EVALUATORS:**

**What to present:**
- Company introduction
- Project title
- Problem statement
- Objectives
- Project abstract
- Wireframes & UI plan
- Technology stack
- GitHub repository link
- Test plan overview

**Each student presents their section:**
- Student 1: Wireframes, UI design decisions
- Student 2: Problem, architecture, tech stack
- Student 3: Test plan, GitHub, objectives

**IMPORTANT:** Missing this review = FAIL in internship

**Deliverable:** Review 1 complete, feedback documented, scores received

---

### WEEK 2: DEVELOPMENT FOUNDATION

#### **Day 7 - 08 June (Monday) - Week 1 Feedback + Week 2 Start**

**STUDENT 1 (Frontend):**
- [ ] Apply Review 1 feedback to wireframes
- [ ] Research React best practices
- [ ] Research form validation libraries
- [ ] Start HTML/React structure for main form

**STUDENT 2 (Backend):**
- [ ] Apply Review 1 feedback to objectives
- [ ] Research similar backend systems
- [ ] Read Express.js documentation
- [ ] Plan database schema

**STUDENT 3 (Testing):**
- [ ] Apply Review 1 feedback to test plan
- [ ] Create test tracker spreadsheet
- [ ] Collect 2-3 reference documents
- [ ] Update logbook

**Deliverable:** Feedback incorporated, research completed

---

#### **Day 8 - 09 June (Tuesday) - Literature Survey & Existing Systems**

**STUDENT 1 (Frontend):**
- [ ] Study 2 existing interior/project management dashboards
- [ ] Note UI patterns: layout, filters, status indicators
- [ ] Document limitations of existing systems
- [ ] Write UI comparison notes

**STUDENT 2 (Backend):**
- [ ] Study 2-3 existing project management systems
- [ ] Write existing system analysis (features + limitations)
- [ ] Define how our system is different/better
- [ ] Document unique features

**STUDENT 3 (Testing):**
- [ ] Summarize 3+ references (5 bullets each)
- [ ] Create literature survey document
- [ ] Verify all sources are cited correctly
- [ ] Add to GitHub

**Deliverable:** Existing System Analysis, Literature Survey with references

---

#### **Day 9 - 10 June (Wednesday) - Database Design & Proposed System**

**STUDENT 1 (Frontend):**
- [ ] Write proposed system description for each screen
- [ ] Create comparison table: Existing vs Proposed
- [ ] Refine wireframes based on final design

**STUDENT 2 (Backend):**
- [ ] Design database schema with tables:
  - users (name, email, role)
  - projects (name, client, status)
  - materials (name, type, unit)
  - procurement (project_id, material_id, quantity_ordered, date)
  - received (procurement_id, quantity, date, supplier)
  - usage (received_id, quantity_used, date)
  - wastage (received_id, quantity_wasted, reason)
  - suppliers (name, contact, invoice_path)
- [ ] Create ER diagram
- [ ] Document validation rules
- [ ] Push to GitHub

**STUDENT 3 (Testing):**
- [ ] Write detailed test plan
- [ ] Map tests to each feature
- [ ] Review ER diagram
- [ ] Update GitHub

**Deliverable:** Proposed System Description, ER Diagram, Database schema

---

#### **Day 10 - 11 June (Thursday) - Database Setup + First API**

**STUDENT 1 (Frontend):**
- [ ] Build form HTML/React structure
- [ ] Add input fields: material name, quantity ordered, date, supplier
- [ ] Apply basic CSS
- [ ] Test in browser

**STUDENT 2 (Backend):**
- [ ] Set up MongoDB/Firebase database
- [ ] Create main materials table
- [ ] Build POST /api/materials endpoint
  ```
  {
    "name": "Plywood",
    "quantity": 100,
    "unit": "sheets",
    "supplier": "ABC Suppliers"
  }
  ```
- [ ] Test with Postman
- [ ] Push code to GitHub

**STUDENT 3 (Testing):**
- [ ] Test POST endpoint with valid data
- [ ] Test with missing fields
- [ ] Test with invalid data
- [ ] Document all results

**Deliverable:** Database created, POST API working, form built

---

#### **Day 11 - 12 June (Friday) - List API + Dashboard HTML**

**STUDENT 1 (Frontend):**
- [ ] Build dashboard HTML/React
- [ ] Show: Material name, Supplier, Qty Ordered, Status
- [ ] Use dummy data to test layout
- [ ] Make responsive

**STUDENT 2 (Backend):**
- [ ] Build GET /api/materials endpoint (returns all)
- [ ] Add filters: ?status=pending&supplier=ABC
- [ ] Test in Postman
- [ ] Return proper JSON

**STUDENT 3 (Testing):**
- [ ] Test GET /api/materials
- [ ] Test with filters
- [ ] Verify JSON structure
- [ ] Push tests to GitHub

**Deliverable:** GET API working, Dashboard HTML complete

---

#### **Day 12 - 13 June (Saturday) - GitHub Workflow & Merge**

**STUDENT 1 (Frontend):**
- [ ] Create branch: `git checkout -b feature/frontend-form`
- [ ] Push frontend files
- [ ] Create pull request
- [ ] Request review

**STUDENT 2 (Backend):**
- [ ] Create branch: `git checkout -b feature/backend-api`
- [ ] Push backend files
- [ ] Create pull request
- [ ] Request review

**STUDENT 3 (Testing):**
- [ ] Review both pull requests
- [ ] Check code quality, naming, structure
- [ ] Approve and merge to main
- [ ] Test merged code end-to-end
- [ ] Document merge results

**Deliverable:** Branches created, PRs merged, main branch stable

---

### WEEK 3: CORE LOGIC DEVELOPMENT

#### **Day 13 - 15 June (Monday) - Core Logic Design**

**STUDENT 1 (Frontend):**
- [ ] Design workflow/status screen
- [ ] Show: ordered → received → used → wastage → balance
- [ ] Create static mockup
- [ ] Write status labels/messages

**STUDENT 2 (Backend):**
- [ ] Write core procurement logic:
  ```
  Balance = Received - Used - Wastage
  Cost per unit = Total Cost / Received
  Wastage % = (Wastage / Received) * 100
  ```
- [ ] Create POST /api/materials/:id/process endpoint
- [ ] Test logic with sample data

**STUDENT 3 (Testing):**
- [ ] Prepare 10 test cases for calculations
- [ ] Test edge cases (0 quantity, negative, etc.)
- [ ] Verify expected outputs
- [ ] Document all results

**Deliverable:** Core logic documented, working function, test cases ready

---

#### **Day 14 - 16 June (Tuesday) - Architecture Diagram + Review 2 Prep**

**STUDENT 1 (Frontend):**
- [ ] Finalize frontend files
- [ ] Prepare slides: Wireframes, UI mockups, workflow
- [ ] Do mock presentation

**STUDENT 2 (Backend):**
- [ ] Create system architecture diagram (draw.io)
- [ ] Show: Frontend → Backend API → Database
- [ ] Prepare slides: Architecture, DB schema, APIs, logic
- [ ] Do mock presentation

**STUDENT 3 (Testing):**
- [ ] Finalize literature survey
- [ ] Prepare slides: Test plan, existing analysis, GitHub status
- [ ] Verify all files on GitHub
- [ ] Do mock presentation

**Deliverable:** Architecture diagram, Review 2 PPT ready

---

#### **Day 15 - 17 June (Wednesday) - Connect Frontend to Backend**

**STUDENT 1 (Frontend):**
- [ ] Add fetch/axios to form
- [ ] POST form data to backend API
- [ ] Show success message
- [ ] Show validation errors

**STUDENT 2 (Backend):**
- [ ] Add server-side validation
- [ ] Return clean JSON responses
- [ ] Add error handling
- [ ] Test from browser

**STUDENT 3 (Testing):**
- [ ] Test full form submission flow
- [ ] Verify database record creation
- [ ] Test validation (empty, long text, special chars)
- [ ] Document all results

**Deliverable:** Frontend-Backend integration working

---

#### **Day 16-17 - 19-20 June (Thu-Fri) - REVIEW 2 PRESENTATION**

**ALL STUDENTS PRESENT:**

**What to present:**
- Literature survey & references
- Existing system analysis
- Proposed system improvements
- System architecture diagram
- Database schema & ER diagram
- Working code demo:
  - Frontend form submission
  - Backend API in Postman
  - Data saved to database
- Test plan overview
- GitHub repository with all code

**IMPORTANT:** Missing this review = FAIL

**Deliverable:** Review 2 complete, feedback documented

---

### WEEK 4: FEATURE COMPLETION

#### **Day 18 - 22 June (Mon-Fri) - Features Complete**

**STUDENT 1 (Frontend):**
- [ ] Day 18: Build dashboard showing all materials
- [ ] Day 19: Add status/action badges (Ordered, Received, Used, Wasted)
- [ ] Day 20: Build detail page for each material
- [ ] Day 21: Polish CSS, responsive design, loading states
- [ ] Day 22: Screenshot all screens

**STUDENT 2 (Backend):**
- [ ] Day 18: Complete GET /api/materials (list with filters)
- [ ] Day 19: Build POST /api/materials/:id/process (calculation logic)
- [ ] Day 20: Build GET /api/materials/:id (detail page data)
- [ ] Day 21: Add error handling, validation
- [ ] Day 22: Deploy to production URL

**STUDENT 3 (Testing):**
- [ ] Day 18: Test full pipeline
- [ ] Day 19: Test with different data scenarios
- [ ] Day 20: Test detail page loading
- [ ] Day 21: Test error cases
- [ ] Day 22: Test deployed version

**Deliverable:** All features working, deployed, tested

---

#### **Day 23 - 24 June (Wed-Thu) - Documentation & Final Prep**

**STUDENT 1 (Frontend):**
- [ ] Record 3-min frontend demo video
- [ ] Write Introduction & UI Design chapter
- [ ] Take screenshots of all pages
- [ ] Upload video to Google Drive

**STUDENT 2 (Backend):**
- [ ] Write System Architecture & Implementation chapters
- [ ] Write database design documentation
- [ ] List all API endpoints with examples
- [ ] Write Conclusion

**STUDENT 3 (Testing):**
- [ ] Write Testing & Deployment chapter
- [ ] Write deployment guide (step-by-step)
- [ ] Create bug report
- [ ] Compile full project report PDF

**Deliverable:** Report draft, demo video, PPT ready

---

#### **Day 25 - 26 June (Fri-Mon) - REVIEW 3 + FINAL SUBMISSION**

**ALL STUDENTS PRESENT FINAL DEMO**

**What to deliver:**
1. ✅ Working prototype (deployed URL)
2. ✅ Live demonstration (all features)
3. ✅ GitHub repository (all code)
4. ✅ Project report (PDF)
5. ✅ PowerPoint presentation
6. ✅ Demo video (3-5 minutes)
7. ✅ Deployment guide
8. ✅ Test report
9. ✅ Team logbook (daily entries)

**IMPORTANT:** This is the FINAL review. All deliverables must be complete.

---

## FINAL DELIVERABLES CHECKLIST

**Code & Repository:**
- [ ] GitHub repository is public
- [ ] All code is pushed and organized
- [ ] Clean commit history
- [ ] README.md with setup instructions
- [ ] .gitignore properly set up

**Frontend:**
- [ ] Material entry form working
- [ ] Dashboard showing all materials
- [ ] Detail page for each material
- [ ] Status/alerts visible
- [ ] Responsive design
- [ ] Deployed URL working

**Backend:**
- [ ] All APIs working (POST, GET, list, detail, process)
- [ ] Database connected and working
- [ ] Calculations correct (balance, wastage %, costs)
- [ ] Error handling on all routes
- [ ] Deployed URL working

**Testing:**
- [ ] Test cases documented
- [ ] All tests passing
- [ ] API testing in Postman (screenshots)
- [ ] End-to-end testing completed
- [ ] Bug report (if any, marked fixed)

**Documentation:**
- [ ] Project report (8-10 pages PDF)
- [ ] Deployment guide (step-by-step)
- [ ] Architecture diagram
- [ ] Database schema diagram
- [ ] API documentation
- [ ] Team logbook (all 26 days)

**Presentation:**
- [ ] PowerPoint (20-25 slides)
- [ ] Demo video (3-5 minutes)
- [ ] Live demo ready for Review 3

---

## TECHNOLOGY COMMANDS REFERENCE

### Frontend Setup
```bash
npx create-react-app frontend
cd frontend
npm install axios tailwindcss
npm start
```

### Backend Setup
```bash
mkdir backend
cd backend
npm init -y
npm install express mongoose dotenv cors
node server.js
```

### Git Commands
```bash
git init
git add .
git commit -m "message"
git push origin main
git checkout -b feature/name
git pull origin main
```

### Testing & Deployment
```bash
# Test API
# Use Postman: Import requests, test endpoints

# Deploy Frontend
# Connect GitHub to Vercel → automatic deployment

# Deploy Backend
# Use Render.com or Railway.app → free tier
```

---

## EVALUATION CRITERIA

**Code Quality (30%)**
- Clean, readable code
- Proper naming conventions
- No console errors
- Proper error handling

**Functionality (30%)**
- All features working
- Calculations correct
- APIs properly connected
- Database working

**Testing (20%)**
- Test cases documented
- Tests passing
- Coverage adequate
- Edge cases tested

**Deployment (10%)**
- Deployed and accessible
- No broken links
- Fast loading
- Responsive design

**Documentation (10%)**
- Report complete
- README clear
- Code comments helpful
- Logbook filled daily

---

## REVIEW DATES (MANDATORY)

| Review | Date | Status |
|--------|------|--------|
| Review 1 | 06 June | Planning & Design |
| Review 2 | 19-20 June | Development & Architecture |
| Review 3 | 29-30 June | Final Demo & Submission |

**Missing any review = FAIL**

---

## TIPS FOR SUCCESS

✅ **Daily Communication** - Team standup every morning  
✅ **Push Code Daily** - Don't lose work, commit often  
✅ **Test Continuously** - Don't wait for end to test  
✅ **Ask Questions Early** - Don't hide blockers  
✅ **Document as You Go** - Write report throughout  
✅ **Deploy Early** - Week 4, not Week 5  
✅ **Practice Presentation** - Multiple mock runs  
✅ **Check GitHub** - Verify all files are there  

---

## CONTACT & SUPPORT

**If stuck:**
1. Check documentation
2. Search online
3. Ask team members
4. Escalate to instructor

**Common Issues:**
- API not working? Check Postman, check backend logs
- Database error? Check connection string, check schema
- Frontend error? Check console, check fetch call
- Deployment failed? Check logs, check file paths

---

## FINAL WORDS

This is a **real project** with **real deadlines** and **mandatory reviews**.

Work hard, stay focused, help each other, and you'll build something amazing! 🚀

**Good luck with your internship!** 💪

---

**Project: Interior Material Procurement & Usage Tracker**  
**Company: Glory Simon Interiors**  
**Duration: 26 Working Days**  
**Team Size: 3 Students**  
**End Goal: Working Prototype + Full Documentation**

